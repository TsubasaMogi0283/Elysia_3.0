【利用規約】を厳守してご使用いただけますようお願いいたします。
詳しくは以下のリンクをご確認ください。

Please use the assets to follow the terms of use.
Check out the link below for the details.

https://docs.google.com/document/d/1fbP6khD485-9c_riIAyNee_5lEkE2pN_9J7RxUiEFUo/edit?usp=sharing


-------------------------------------------------------------------------------------------------------

CSgraphicart BOOTH shop / https://csgraphicart.booth.pm/
Chiharu Suzuki
Twitter : @Rucchicchy
